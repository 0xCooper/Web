# lyric-demo
This is a demo "how to synchronize lyric in html5 &lt;audio>"
You can checkout gh-pages branch and fork this repo.
